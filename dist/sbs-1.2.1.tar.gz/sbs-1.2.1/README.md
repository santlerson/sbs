# Shmoosey's Backup Software
A tool for making remote, yet encrypted secure backups on Google Drive
