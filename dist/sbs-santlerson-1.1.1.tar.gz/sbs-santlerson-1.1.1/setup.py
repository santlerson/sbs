import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="sbs-santlerson",
    version="1.1.1",
    author="Shmoosey Antlerson",
    author_email="shmooseyantlerson@gmail.com",
    description="A service for creating secure, encrypted backups on Google Drive",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/santlerson/sbs",
    project_urls={
        "Bug Tracker": "https://github.com/santlerson/sbs/issues",
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: GNU GENERAL PUBLIC LICENSE",

        "Operating System :: OS Independent",
    ],
    package_dir={"": "src"},
    packages=setuptools.find_packages(where="src"),
    python_requires=">=3.6",
    entry_points = {
        'console_scripts': ['sbs=src.sbs:main'],
    }
)